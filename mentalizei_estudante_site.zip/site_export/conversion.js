// Funcionalidades para o contador regressivo e elementos de conversão
document.addEventListener('DOMContentLoaded', function() {
    // Contador regressivo
    function startCountdown() {
        const hoursElement = document.getElementById('hours');
        const minutesElement = document.getElementById('minutes');
        const secondsElement = document.getElementById('seconds');
        
        if (!hoursElement || !minutesElement || !secondsElement) return;
        
        let hours = parseInt(hoursElement.textContent);
        let minutes = parseInt(minutesElement.textContent);
        let seconds = parseInt(secondsElement.textContent);
        
        const countdownInterval = setInterval(function() {
            seconds--;
            
            if (seconds < 0) {
                seconds = 59;
                minutes--;
                
                if (minutes < 0) {
                    minutes = 59;
                    hours--;
                    
                    if (hours < 0) {
                        hours = 23;
                    }
                }
            }
            
            hoursElement.textContent = hours < 10 ? '0' + hours : hours;
            minutesElement.textContent = minutes < 10 ? '0' + minutes : minutes;
            secondsElement.textContent = seconds < 10 ? '0' + seconds : seconds;
        }, 1000);
    }
    
    // Iniciar o contador
    startCountdown();
    
    // Pop-up de saída
    function setupExitIntent() {
        let exitShown = false;
        
        document.addEventListener('mouseleave', function(e) {
            if (e.clientY < 0 && !exitShown) {
                exitShown = true;
                showExitPopup();
            }
        });
        
        function showExitPopup() {
            const exitPopup = document.createElement('div');
            exitPopup.className = 'exit-popup';
            exitPopup.innerHTML = `
                <div class="exit-popup-content">
                    <span class="close-exit">&times;</span>
                    <h3>Espere! Não perca essa oportunidade!</h3>
                    <p>Temos um desconto especial de 15% para você que está decidindo agora.</p>
                    <div class="exit-offer">
                        <div class="exit-price">
                            <span class="old-price">R$497</span>
                            <span class="new-price">R$422</span>
                        </div>
                        <p>Oferta válida apenas por mais 15 minutos!</p>
                    </div>
                    <a href="https://pay.hotmart.com/XXXXXXXX?discount=15OFF" class="btn-cta" target="_blank">APROVEITAR DESCONTO ESPECIAL</a>
                </div>
            `;
            
            document.body.appendChild(exitPopup);
            
            // Estilo para o pop-up de saída
            const style = document.createElement('style');
            style.textContent = `
                .exit-popup {
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.7);
                    display: flex;
                    justify-content: center;
                    align-items: center;
                    z-index: 9999;
                }
                
                .exit-popup-content {
                    background-color: white;
                    padding: 30px;
                    border-radius: 10px;
                    max-width: 500px;
                    text-align: center;
                    position: relative;
                }
                
                .close-exit {
                    position: absolute;
                    top: 10px;
                    right: 15px;
                    font-size: 24px;
                    cursor: pointer;
                }
                
                .exit-offer {
                    background-color: #f9f9f9;
                    padding: 15px;
                    margin: 15px 0;
                    border-radius: 5px;
                }
                
                .exit-price {
                    margin: 10px 0;
                }
                
                .exit-price .old-price {
                    text-decoration: line-through;
                    color: #999;
                    margin-right: 10px;
                }
                
                .exit-price .new-price {
                    font-size: 24px;
                    font-weight: bold;
                    color: #800020;
                }
            `;
            
            document.head.appendChild(style);
            
            // Fechar o pop-up ao clicar no X
            document.querySelector('.close-exit').addEventListener('click', function() {
                document.body.removeChild(exitPopup);
            });
        }
    }
    
    // Configurar o pop-up de saída
    setupExitIntent();
    
    // Botão flutuante de CTA
    function createFloatingCTA() {
        const floatingCTA = document.createElement('div');
        floatingCTA.className = 'floating-cta';
        floatingCTA.innerHTML = `
            <a href="https://pay.hotmart.com/XXXXXXXX" class="btn-float" target="_blank">
                GARANTIR ACESSO
            </a>
        `;
        
        document.body.appendChild(floatingCTA);
        
        // Estilo para o botão flutuante
        const style = document.createElement('style');
        style.textContent = `
            .floating-cta {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 999;
            }
            
            .btn-float {
                display: inline-block;
                padding: 15px 25px;
                background-color: #FF6B00;
                color: white;
                text-decoration: none;
                font-weight: bold;
                border-radius: 30px;
                box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
                transition: all 0.3s ease;
            }
            
            .btn-float:hover {
                transform: translateY(-5px);
                box-shadow: 0 6px 15px rgba(0, 0, 0, 0.4);
            }
            
            @media (max-width: 768px) {
                .floating-cta {
                    bottom: 10px;
                    right: 10px;
                }
                
                .btn-float {
                    padding: 10px 15px;
                    font-size: 14px;
                }
            }
        `;
        
        document.head.appendChild(style);
    }
    
    // Criar o botão flutuante
    createFloatingCTA();
    
    // Mostrar/ocultar tópicos abordados
    const toggleButtons = document.querySelectorAll('.toggle-topics');
    toggleButtons.forEach(button => {
        button.addEventListener('click', function() {
            const topicsContent = this.nextElementSibling;
            if (topicsContent.classList.contains('hidden')) {
                topicsContent.classList.remove('hidden');
                this.textContent = '▼ Ocultar tópicos abordados';
            } else {
                topicsContent.classList.add('hidden');
                this.textContent = '▶ Ver tópicos abordados';
            }
        });
    });
});
