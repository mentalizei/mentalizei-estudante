// Script para criar imagens representativas para as disciplinas
const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const path = require('path');

// Configurações
const outputDir = path.join(__dirname, 'images');
const width = 800;
const height = 600;
const subjects = [
    {
        name: 'bioquimica',
        title: 'BIOQUÍMICA',
        bgColor: '#800020',
        elements: [
            { type: 'circle', x: 400, y: 300, radius: 150, color: '#ffffff', opacity: 0.8 },
            { type: 'hexagon', x: 400, y: 300, size: 100, color: '#4CAF50', opacity: 0.9 },
            { type: 'text', x: 400, y: 300, text: 'C₆H₁₂O₆', font: 'bold 40px Arial', color: '#ffffff' },
            { type: 'molecule', x: 400, y: 180, size: 120, color: '#ffffff' }
        ]
    },
    {
        name: 'fisiologia',
        title: 'FISIOLOGIA HUMANA',
        bgColor: '#800020',
        elements: [
            { type: 'heart', x: 400, y: 300, size: 150, color: '#ff5252', opacity: 0.9 },
            { type: 'pulse', x: 400, y: 400, width: 300, height: 50, color: '#ffffff', opacity: 0.8 },
            { type: 'circle', x: 400, y: 300, radius: 200, color: '#ffffff', opacity: 0.2 }
        ]
    },
    {
        name: 'anatomia',
        title: 'ANATOMIA HUMANA',
        bgColor: '#800020',
        elements: [
            { type: 'silhouette', x: 400, y: 300, width: 200, height: 350, color: '#ffffff', opacity: 0.8 },
            { type: 'bones', x: 400, y: 300, width: 150, height: 300, color: '#ffffff', opacity: 0.9 },
            { type: 'circle', x: 400, y: 300, radius: 220, color: '#ffffff', opacity: 0.1 }
        ]
    },
    {
        name: 'microbiologia',
        title: 'MICROBIOLOGIA',
        bgColor: '#800020',
        elements: [
            { type: 'bacteria', x: 400, y: 300, size: 180, color: '#4CAF50', opacity: 0.8 },
            { type: 'virus', x: 250, y: 200, size: 100, color: '#5D4037', opacity: 0.7 },
            { type: 'cell', x: 550, y: 400, size: 120, color: '#ffffff', opacity: 0.7 },
            { type: 'circle', x: 400, y: 300, radius: 250, color: '#ffffff', opacity: 0.1 }
        ]
    },
    {
        name: 'avaliacao-nutricional',
        title: 'AVALIAÇÃO NUTRICIONAL',
        bgColor: '#800020',
        elements: [
            { type: 'scale', x: 400, y: 300, size: 200, color: '#ffffff', opacity: 0.8 },
            { type: 'apple', x: 300, y: 200, size: 80, color: '#4CAF50', opacity: 0.9 },
            { type: 'ruler', x: 500, y: 400, width: 200, height: 40, color: '#ffffff', opacity: 0.7 },
            { type: 'circle', x: 400, y: 300, radius: 220, color: '#ffffff', opacity: 0.1 }
        ]
    },
    {
        name: 'tecnica-dietetica',
        title: 'TÉCNICA DIETÉTICA',
        bgColor: '#800020',
        elements: [
            { type: 'plate', x: 400, y: 300, size: 200, color: '#ffffff', opacity: 0.8 },
            { type: 'food', x: 400, y: 300, size: 150, color: '#4CAF50', opacity: 0.7 },
            { type: 'utensils', x: 550, y: 200, size: 100, color: '#ffffff', opacity: 0.7 },
            { type: 'circle', x: 400, y: 300, radius: 220, color: '#ffffff', opacity: 0.1 }
        ]
    },
    {
        name: 'nutricao-clinica',
        title: 'NUTRIÇÃO CLÍNICA',
        bgColor: '#800020',
        elements: [
            { type: 'medical', x: 400, y: 300, size: 200, color: '#ffffff', opacity: 0.8 },
            { type: 'heart', x: 300, y: 250, size: 80, color: '#ff5252', opacity: 0.7 },
            { type: 'food', x: 500, y: 350, size: 100, color: '#4CAF50', opacity: 0.7 },
            { type: 'circle', x: 400, y: 300, radius: 220, color: '#ffffff', opacity: 0.1 }
        ]
    }
];

// Função para criar imagens de disciplinas
async function createSubjectImages() {
    // Criar diretório de saída se não existir
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    // Criar imagens para cada disciplina
    for (const subject of subjects) {
        await createSubjectImage(subject);
    }

    console.log('Todas as imagens foram criadas com sucesso!');
}

// Função para criar imagem de disciplina
async function createSubjectImage(subject) {
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fundo
    ctx.fillStyle = subject.bgColor;
    ctx.fillRect(0, 0, width, height);

    // Título vertical
    ctx.save();
    ctx.translate(100, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.font = 'bold 60px Montserrat';
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.fillText(subject.title, 0, 0);
    ctx.restore();

    // Desenhar elementos
    for (const element of subject.elements) {
        drawElement(ctx, element);
    }

    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(outputDir, `${subject.name}-realistic.png`), buffer);
    console.log(`Imagem criada: ${subject.name}-realistic.png`);
}

// Função para desenhar elementos
function drawElement(ctx, element) {
    ctx.save();
    ctx.globalAlpha = element.opacity || 1;
    
    switch (element.type) {
        case 'circle':
            drawCircle(ctx, element);
            break;
        case 'hexagon':
            drawHexagon(ctx, element);
            break;
        case 'text':
            drawText(ctx, element);
            break;
        case 'molecule':
            drawMolecule(ctx, element);
            break;
        case 'heart':
            drawHeart(ctx, element);
            break;
        case 'pulse':
            drawPulse(ctx, element);
            break;
        case 'silhouette':
            drawSilhouette(ctx, element);
            break;
        case 'bones':
            drawBones(ctx, element);
            break;
        case 'bacteria':
            drawBacteria(ctx, element);
            break;
        case 'virus':
            drawVirus(ctx, element);
            break;
        case 'cell':
            drawCell(ctx, element);
            break;
        case 'scale':
            drawScale(ctx, element);
            break;
        case 'apple':
            drawApple(ctx, element);
            break;
        case 'ruler':
            drawRuler(ctx, element);
            break;
        case 'plate':
            drawPlate(ctx, element);
            break;
        case 'food':
            drawFood(ctx, element);
            break;
        case 'utensils':
            drawUtensils(ctx, element);
            break;
        case 'medical':
            drawMedical(ctx, element);
            break;
    }
    
    ctx.restore();
}

// Funções para desenhar elementos específicos
function drawCircle(ctx, element) {
    ctx.beginPath();
    ctx.arc(element.x, element.y, element.radius, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
}

function drawHexagon(ctx, element) {
    const size = element.size;
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2;
        const x = element.x + size * Math.cos(angle);
        const y = element.y + size * Math.sin(angle);
        if (i === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    }
    ctx.closePath();
    ctx.fillStyle = element.color;
    ctx.fill();
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 3;
    ctx.stroke();
}

function drawText(ctx, element) {
    ctx.font = element.font;
    ctx.fillStyle = element.color;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(element.text, element.x, element.y);
}

function drawMolecule(ctx, element) {
    // Desenhar estrutura molecular simples
    const size = element.size;
    const centerX = element.x;
    const centerY = element.y;
    
    // Desenhar átomos
    const atoms = [
        { x: centerX, y: centerY },
        { x: centerX + size/2, y: centerY - size/3 },
        { x: centerX - size/2, y: centerY - size/3 },
        { x: centerX, y: centerY - size/1.5 },
        { x: centerX + size/2, y: centerY + size/3 },
        { x: centerX - size/2, y: centerY + size/3 }
    ];
    
    // Desenhar ligações
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 4;
    
    ctx.beginPath();
    ctx.moveTo(atoms[0].x, atoms[0].y);
    ctx.lineTo(atoms[1].x, atoms[1].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(atoms[0].x, atoms[0].y);
    ctx.lineTo(atoms[2].x, atoms[2].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(atoms[1].x, atoms[1].y);
    ctx.lineTo(atoms[3].x, atoms[3].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(atoms[2].x, atoms[2].y);
    ctx.lineTo(atoms[3].x, atoms[3].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(atoms[0].x, atoms[0].y);
    ctx.lineTo(atoms[4].x, atoms[4].y);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(atoms[0].x, atoms[0].y);
    ctx.lineTo(atoms[5].x, atoms[5].y);
    ctx.stroke();
    
    // Desenhar átomos
    atoms.forEach(atom => {
        ctx.beginPath();
        ctx.arc(atom.x, atom.y, 15, 0, Math.PI * 2);
        ctx.fillStyle = element.color;
        ctx.fill();
    });
}

function drawHeart(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    ctx.beginPath();
    ctx.moveTo(x, y - size/4);
    ctx.bezierCurveTo(
        x, y - size/2,
        x - size/2, y - size/2,
        x - size/2, y - size/4
    );
    ctx.bezierCurveTo(
        x - size/2, y,
        x, y + size/2,
        x, y + size/2
    );
    ctx.bezierCurveTo(
        x, y + size/2,
        x + size/2, y,
        x + size/2, y - size/4
    );
    ctx.bezierCurveTo(
        x + size/2, y - size/2,
        x, y - size/2,
        x, y - size/4
    );
    ctx.fillStyle = element.color;
    ctx.fill();
}

function drawPulse(ctx, element) {
    const width = element.width;
    const height = element.height;
    const x = element.x - width/2;
    const y = element.y - height/2;
    
    ctx.beginPath();
    ctx.moveTo(x, y + height/2);
    ctx.lineTo(x + width * 0.2, y + height/2);
    ctx.lineTo(x + width * 0.3, y);
    ctx.lineTo(x + width * 0.4, y + height);
    ctx.lineTo(x + width * 0.5, y + height/4);
    ctx.lineTo(x + width * 0.6, y + height/2);
    ctx.lineTo(x + width * 0.8, y + height/2);
    ctx.lineTo(x + width, y + height/2);
    
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 5;
    ctx.stroke();
}

function drawSilhouette(ctx, element) {
    const width = element.width;
    const height = element.height;
    const x = element.x;
    const y = element.y;
    
    // Cabeça
    ctx.beginPath();
    ctx.arc(x, y - height/2 + width/4, width/4, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Corpo
    ctx.beginPath();
    ctx.moveTo(x, y - height/2 + width/2);
    ctx.lineTo(x, y + height/2 - width/4);
    
    // Braços
    ctx.moveTo(x, y - height/4);
    ctx.lineTo(x - width/2, y);
    ctx.moveTo(x, y - height/4);
    ctx.lineTo(x + width/2, y);
    
    // Pernas
    ctx.moveTo(x, y + height/2 - width/4);
    ctx.lineTo(x - width/4, y + height/2);
    ctx.moveTo(x, y + height/2 - width/4);
    ctx.lineTo(x + width/4, y + height/2);
    
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 8;
    ctx.stroke();
}

function drawBones(ctx, element) {
    const width = element.width;
    const height = element.height;
    const x = element.x;
    const y = element.y;
    
    // Coluna vertebral
    ctx.beginPath();
    ctx.moveTo(x, y - height/2 + width/4);
    ctx.lineTo(x, y + height/2 - width/4);
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 10;
    ctx.stroke();
    
    // Costelas
    for (let i = 0; i < 5; i++) {
        const yPos = y - height/4 + i * height/10;
        
        ctx.beginPath();
        ctx.moveTo(x, yPos);
        ctx.bezierCurveTo(
            x + width/4, yPos,
            x + width/3, yPos - height/40,
            x + width/2, yPos
        );
        ctx.strokeStyle = element.color;
        ctx.lineWidth = 5;
        ctx.stroke();
        
        ctx.beginPath();
        ctx.moveTo(x, yPos);
        ctx.bezierCurveTo(
            x - width/4, yPos,
            x - width/3, yPos - height/40,
            x - width/2, yPos
        );
        ctx.strokeStyle = element.color;
        ctx.lineWidth = 5;
        ctx.stroke();
    }
    
    // Pélvis
    ctx.beginPath();
    ctx.moveTo(x - width/3, y + height/4);
    ctx.lineTo(x + width/3, y + height/4);
    ctx.bezierCurveTo(
        x + width/4, y + height/3,
        x + width/4, y + height/2.5,
        x, y + height/2
    );
    ctx.bezierCurveTo(
        x - width/4, y + height/2.5,
        x - width/4, y + height/3,
        x - width/3, y + height/4
    );
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 5;
    ctx.stroke();
}

function drawBacteria(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Corpo da bactéria
    ctx.beginPath();
    ctx.ellipse(x, y, size/2, size/4, 0, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Flagelos
    for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const startX = x + (size/2) * Math.cos(angle);
        const startY = y + (size/4) * Math.sin(angle);
        
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.bezierCurveTo(
            startX + (size/4) * Math.cos(angle),
            startY + (size/4) * Math.sin(angle),
            startX + (size/3) * Math.cos(angle + 0.5),
            startY + (size/3) * Math.sin(angle + 0.5),
            startX + (size/2) * Math.cos(angle)
        );
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2;
        ctx.stroke();
    }
    
    // Detalhes internos
    for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.arc(x - size/6 + i * size/6, y, size/12, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
    }
}

function drawVirus(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Corpo do vírus
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Espículas
    for (let i = 0; i < 16; i++) {
        const angle = (i / 16) * Math.PI * 2;
        const startX = x + (size/2) * Math.cos(angle);
        const startY = y + (size/2) * Math.sin(angle);
        const endX = x + (size) * Math.cos(angle);
        const endY = y + (size) * Math.sin(angle);
        
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Ponta da espícula
        ctx.beginPath();
        ctx.arc(endX, endY, size/15, 0, Math.PI * 2);
        ctx.fillStyle = '#ffffff';
        ctx.fill();
    }
    
    // Detalhes internos
    ctx.beginPath();
    ctx.arc(x, y, size/4, 0, Math.PI * 2);
    ctx.fillStyle = '#ffffff';
    ctx.globalAlpha = 0.5;
    ctx.fill();
}

function drawCell(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Membrana celular
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 3;
    ctx.globalAlpha = 0.8;
    ctx.stroke();
    
    // Núcleo
    ctx.beginPath();
    ctx.arc(x, y, size/4, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.globalAlpha = 0.8;
    ctx.fill();
    
    // Organelas
    for (let i = 0; i < 5; i++) {
        const angle = (i / 5) * Math.PI * 2;
        const orgX = x + (size/3) * Math.cos(angle);
        const orgY = y + (size/3) * Math.sin(angle);
        
        ctx.beginPath();
        ctx.arc(orgX, orgY, size/10, 0, Math.PI * 2);
        ctx.fillStyle = element.color;
        ctx.globalAlpha = 0.6;
        ctx.fill();
    }
}

function drawScale(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Base da balança
    ctx.beginPath();
    ctx.rect(x - size/3, y + size/4, size/1.5, size/10);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Suporte
    ctx.beginPath();
    ctx.rect(x - size/20, y - size/4, size/10, size/2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Plataforma
    ctx.beginPath();
    ctx.ellipse(x, y - size/4, size/3, size/10, 0, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Mostrador
    ctx.beginPath();
    ctx.rect(x - size/5, y + size/4 - size/3, size/2.5, size/4);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Detalhes do mostrador
    ctx.beginPath();
    ctx.moveTo(x - size/6, y + size/4 - size/4);
    ctx.lineTo(x + size/6, y + size/4 - size/4);
    ctx.strokeStyle = '#800020';
    ctx.lineWidth = 2;
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(x - size/6, y + size/4 - size/6);
    ctx.lineTo(x + size/10, y + size/4 - size/6);
    ctx.strokeStyle = '#800020';
    ctx.lineWidth = 2;
    ctx.stroke();
}

function drawApple(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Corpo da maçã
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Haste
    ctx.beginPath();
    ctx.moveTo(x, y - size/2);
    ctx.quadraticCurveTo(x, y - size/1.5, x + size/10, y - size/1.5);
    ctx.strokeStyle = '#5D4037';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Folha
    ctx.beginPath();
    ctx.moveTo(x, y - size/1.8);
    ctx.quadraticCurveTo(x + size/4, y - size/1.5, x + size/8, y - size/2.5);
    ctx.quadraticCurveTo(x + size/10, y - size/2, x, y - size/1.8);
    ctx.fillStyle = '#4CAF50';
    ctx.fill();
}

function drawRuler(ctx, element) {
    const width = element.width;
    const height = element.height;
    const x = element.x - width/2;
    const y = element.y - height/2;
    
    // Régua
    ctx.beginPath();
    ctx.rect(x, y, width, height);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Marcações
    for (let i = 0; i <= 10; i++) {
        const markX = x + (width / 10) * i;
        let markHeight = height / 3;
        
        if (i % 5 === 0) {
            markHeight = height / 1.5;
        }
        
        ctx.beginPath();
        ctx.moveTo(markX, y);
        ctx.lineTo(markX, y + markHeight);
        ctx.strokeStyle = '#800020';
        ctx.lineWidth = 2;
        ctx.stroke();
        
        if (i % 5 === 0) {
            ctx.font = 'bold 16px Arial';
            ctx.fillStyle = '#800020';
            ctx.textAlign = 'center';
            ctx.fillText(i * 10, markX, y + height - 5);
        }
    }
}

function drawPlate(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Prato
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Borda do prato
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.strokeStyle = '#800020';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Borda interna
    ctx.beginPath();
    ctx.arc(x, y, size/2.5, 0, Math.PI * 2);
    ctx.strokeStyle = '#800020';
    ctx.lineWidth = 1;
    ctx.stroke();
}

function drawFood(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Desenhar diferentes alimentos
    
    // Vegetais (verde)
    ctx.beginPath();
    ctx.arc(x - size/4, y - size/4, size/8, 0, Math.PI * 2);
    ctx.fillStyle = '#4CAF50';
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc(x + size/5, y - size/6, size/10, 0, Math.PI * 2);
    ctx.fillStyle = '#8BC34A';
    ctx.fill();
    
    // Proteína (marrom)
    ctx.beginPath();
    ctx.ellipse(x, y + size/8, size/4, size/6, 0, 0, Math.PI * 2);
    ctx.fillStyle = '#795548';
    ctx.fill();
    
    // Carboidrato (amarelo)
    ctx.beginPath();
    ctx.arc(x + size/4, y + size/4, size/7, 0, Math.PI * 2);
    ctx.fillStyle = '#FFC107';
    ctx.fill();
    
    // Frutas (vermelho)
    ctx.beginPath();
    ctx.arc(x - size/3, y + size/5, size/12, 0, Math.PI * 2);
    ctx.fillStyle = '#F44336';
    ctx.fill();
}

function drawUtensils(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Garfo
    ctx.beginPath();
    ctx.moveTo(x - size/4, y - size/2);
    ctx.lineTo(x - size/4, y + size/4);
    ctx.moveTo(x - size/4 - size/10, y - size/2);
    ctx.lineTo(x - size/4 - size/10, y);
    ctx.moveTo(x - size/4 + size/10, y - size/2);
    ctx.lineTo(x - size/4 + size/10, y);
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Faca
    ctx.beginPath();
    ctx.moveTo(x + size/4, y - size/2);
    ctx.lineTo(x + size/4, y + size/4);
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 3;
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(x + size/4, y - size/2);
    ctx.lineTo(x + size/4 + size/10, y - size/2);
    ctx.lineTo(x + size/4, y - size/4);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Colher
    ctx.beginPath();
    ctx.moveTo(x, y - size/2);
    ctx.lineTo(x, y);
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 3;
    ctx.stroke();
    
    ctx.beginPath();
    ctx.ellipse(x, y + size/4, size/8, size/16, 0, 0, Math.PI * 2);
    ctx.fillStyle = element.color;
    ctx.fill();
}

function drawMedical(ctx, element) {
    const size = element.size;
    const x = element.x;
    const y = element.y;
    
    // Símbolo médico (cruz)
    ctx.beginPath();
    ctx.rect(x - size/10, y - size/3, size/5, size/1.5);
    ctx.rect(x - size/3, y - size/10, size/1.5, size/5);
    ctx.fillStyle = element.color;
    ctx.fill();
    
    // Círculo em volta
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.strokeStyle = element.color;
    ctx.lineWidth = 5;
    ctx.stroke();
}

// Executar a criação de imagens
createSubjectImages().catch(err => {
    console.error('Erro ao criar imagens:', err);
});
