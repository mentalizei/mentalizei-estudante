# Instruções para Hospedagem e Edição do Site mentalizei.estudante

Este documento contém instruções detalhadas sobre como hospedar seu site em diferentes plataformas e como fazer edições futuras.

## Opções de Hospedagem

### 1. GitHub Pages (Gratuito)

1. Crie uma conta no [GitHub](https://github.com/) se ainda não tiver uma
2. Crie um novo repositório (pode ser chamado "mentalizei-estudante")
3. Faça upload de todos os arquivos do pacote ZIP para o repositório
4. Vá para "Settings" > "Pages"
5. Em "Source", selecione "main" (ou "master") e a pasta raiz "/"
6. Clique em "Save"
7. Seu site estará disponível em `https://seuusuario.github.io/mentalizei-estudante`

### 2. Netlify (Gratuito)

1. Crie uma conta no [Netlify](https://www.netlify.com/)
2. Clique em "New site from Git" ou "Deploy manually"
3. Se escolher "Deploy manually", arraste e solte a pasta descompactada
4. Se escolher "New site from Git", conecte ao GitHub e selecione seu repositório
5. Seu site estará disponível em um domínio aleatório da Netlify (ex: `https://mentalizei-estudante.netlify.app`)
6. Você pode configurar um domínio personalizado nas configurações

### 3. Vercel (Gratuito)

1. Crie uma conta no [Vercel](https://vercel.com/)
2. Clique em "New Project"
3. Importe do GitHub ou faça upload direto dos arquivos
4. Seu site estará disponível em um domínio da Vercel (ex: `https://mentalizei-estudante.vercel.app`)
5. Você pode configurar um domínio personalizado nas configurações

## Como Editar o Site

### Edição Básica (HTML/CSS)

1. **Estrutura do site:**
   - `index.html` - Página principal do site
   - `styles.css` - Estilos e aparência do site
   - `images/` - Pasta com todas as imagens
   - `*.js` - Arquivos JavaScript para funcionalidades

2. **Para editar o conteúdo:**
   - Abra o arquivo `index.html` em qualquer editor de texto (Notepad++, Visual Studio Code, etc.)
   - Modifique os textos entre as tags HTML
   - Salve o arquivo

3. **Para editar o estilo:**
   - Abra o arquivo `styles.css` em um editor de texto
   - Modifique as propriedades CSS para alterar cores, tamanhos, etc.
   - Salve o arquivo

4. **Para substituir imagens:**
   - Mantenha os mesmos nomes de arquivo para facilitar
   - Ou atualize os nomes no HTML se usar novos nomes

### Ferramentas Recomendadas para Edição

1. **Visual Studio Code** (gratuito) - [Download](https://code.visualstudio.com/)
   - Excelente para editar HTML, CSS e JavaScript
   - Possui extensões úteis como "Live Server" para visualizar mudanças em tempo real

2. **GitHub Desktop** (gratuito) - [Download](https://desktop.github.com/)
   - Facilita o gerenciamento de arquivos se estiver usando GitHub Pages

3. **FileZilla** (gratuito) - [Download](https://filezilla-project.org/)
   - Para transferir arquivos via FTP se estiver usando hospedagem tradicional

## Dicas para Manutenção

1. **Sempre faça backup** antes de editar os arquivos
2. **Teste localmente** antes de publicar (use a extensão Live Server no VS Code)
3. **Mantenha a estrutura de pastas** para evitar links quebrados
4. **Otimize imagens** para melhorar o desempenho do site (use ferramentas como TinyPNG)

## Recursos Adicionais

- [W3Schools HTML Tutorial](https://www.w3schools.com/html/)
- [W3Schools CSS Tutorial](https://www.w3schools.com/css/)
- [MDN Web Docs](https://developer.mozilla.org/pt-BR/docs/Web)

Se precisar de ajuda adicional, existem muitos fóruns e comunidades online como Stack Overflow onde você pode fazer perguntas específicas sobre edição de sites.
