// Script para criar ícones SVG para o site mentalizei.estudante
const fs = require('fs');
const path = require('path');

// Diretório de saída
const outputDir = path.join(__dirname, 'images');

// Verificar se o diretório existe
if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
}

// Cor principal para os ícones
const iconColor = '#800020'; // Bordô

// Definição dos ícones SVG
const icons = {
    'efficiency': `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
        <g fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M35,30 C35,20 45,15 55,20 C65,25 75,20 75,10"/>
            <circle cx="50" cy="55" r="25"/>
            <circle cx="50" cy="55" r="20"/>
            <path d="M50,40 L50,55 L60,65"/>
            <circle cx="50" cy="55" r="3" fill="${iconColor}"/>
            <path d="M30,80 L30,90 L70,90 L70,80"/>
            <rect x="40" y="75" width="20" height="15" rx="2"/>
            <circle cx="35" cy="30" r="5" fill="${iconColor}"/>
            <path d="M35,30 L40,35 L35,40"/>
        </g>
    </svg>`,
    
    'flexibility': `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
        <g fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="20" y="20" width="60" height="45" rx="2"/>
            <rect x="25" y="25" width="50" height="30"/>
            <line x1="25" y1="60" x2="75" y2="60"/>
            <line x1="35" y1="60" x2="35" y2="65"/>
            <line x1="50" y1="60" x2="50" y2="65"/>
            <line x1="65" y1="60" x2="65" y2="65"/>
            <rect x="30" y="70" width="40" height="15" rx="2"/>
            <line x1="35" y1="30" x2="65" y2="30"/>
            <line x1="35" y1="35" x2="65" y2="35"/>
            <line x1="35" y1="40" x2="55" y2="40"/>
            <line x1="35" y1="45" x2="60" y2="45"/>
            <line x1="35" y1="50" x2="50" y2="50"/>
        </g>
    </svg>`,
    
    'understanding': `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
        <g fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M50,20 C65,20 75,35 70,50 C65,65 50,70 35,65 C20,60 15,45 25,35 C35,25 45,25 50,20 Z"/>
            <path d="M30,40 C35,35 45,35 50,40 C55,45 65,45 70,40"/>
            <path d="M30,50 C35,45 45,45 50,50 C55,55 65,55 70,50"/>
            <circle cx="40" cy="30" r="3" fill="${iconColor}"/>
            <circle cx="60" cy="30" r="3" fill="${iconColor}"/>
            <path d="M45,60 L55,60 L55,70 L60,70 L50,80 L40,70 L45,70 Z"/>
            <circle cx="50" cy="50" r="3" fill="${iconColor}"/>
            <path d="M50,50 L55,45"/>
            <path d="M50,50 L45,45"/>
        </g>
    </svg>`,
    
    'quality': `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
        <g fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="50" cy="40" r="20"/>
            <path d="M50,20 L50,15"/>
            <path d="M50,65 L50,60"/>
            <path d="M30,40 L25,40"/>
            <path d="M75,40 L70,40"/>
            <path d="M37,27 L33,23"/>
            <path d="M67,57 L63,53"/>
            <path d="M37,53 L33,57"/>
            <path d="M67,23 L63,27"/>
            <path d="M45,40 L55,40"/>
            <path d="M50,35 L50,45"/>
            <path d="M20,80 C20,70 35,65 50,70 C65,75 80,70 80,60"/>
            <path d="M20,70 L20,80 L30,80"/>
            <path d="M80,60 L80,70 L70,70"/>
        </g>
    </svg>`,
    
    'pdf': `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
        <g fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="25" y="15" width="40" height="55" rx="2"/>
            <path d="M35,25 L55,25"/>
            <path d="M35,35 L55,35"/>
            <path d="M35,45 L45,45"/>
            <rect x="35" y="55" width="20" height="10" rx="1"/>
            <rect x="40" y="20" width="30" height="60" rx="2"/>
            <path d="M50,30 L60,30"/>
            <path d="M50,40 L60,40"/>
            <path d="M50,50 L55,50"/>
            <rect x="50" y="60" width="15" height="15" rx="1"/>
            <line x1="70" y1="25" x2="70" y2="75"/>
            <path d="M70,30 L75,30"/>
            <path d="M70,40 L75,40"/>
            <path d="M70,50 L75,50"/>
            <path d="M70,60 L75,60"/>
            <path d="M70,70 L75,70"/>
        </g>
    </svg>`,
    
    'validated': `<svg xmlns="http://www.w3.org/2000/svg" width="100" height="100" viewBox="0 0 100 100">
        <g fill="none" stroke="${iconColor}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <rect x="25" y="20" width="50" height="60" rx="2"/>
            <path d="M35,30 L65,30"/>
            <path d="M35,40 L65,40"/>
            <path d="M35,50 L55,50"/>
            <rect x="20" y="30" width="40" height="50" rx="2"/>
            <path d="M30,40 L50,40"/>
            <path d="M30,50 L50,50"/>
            <path d="M30,60 L45,60"/>
            <rect x="40" y="40" width="40" height="50" rx="2"/>
            <path d="M50,50 L70,50"/>
            <path d="M50,60 L70,60"/>
            <path d="M50,70 L65,70"/>
            <path d="M50,80 L60,80"/>
            <path d="M60,20 L70,10 L80,20"/>
            <path d="M70,10 L70,30"/>
        </g>
    </svg>`
};

// Salvar os ícones como arquivos SVG
Object.entries(icons).forEach(([name, svg]) => {
    const filePath = path.join(outputDir, `icon-${name}.svg`);
    fs.writeFileSync(filePath, svg);
    console.log(`Ícone SVG criado: ${filePath}`);
});

console.log('Todos os ícones SVG foram criados com sucesso!');
