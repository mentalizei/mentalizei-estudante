// Script para criar imagens realistas para o site mentalizei.estudante
const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const path = require('path');

// Configurações
const outputDir = path.join(__dirname, 'images');
const width = 800;
const height = 600;
const subjects = [
    {
        name: 'bioquimica',
        title: 'BIOQUÍMICA',
        bgColor: '#800020',
        mainImage: 'biochemistry.jpg'
    },
    {
        name: 'fisiologia',
        title: 'FISIOLOGIA',
        bgColor: '#800020',
        mainImage: 'physiology.jpg'
    },
    {
        name: 'anatomia',
        title: 'ANATOMIA',
        bgColor: '#800020',
        mainImage: 'anatomy.jpg'
    },
    {
        name: 'microbiologia',
        title: 'MICROBIOLOGIA',
        bgColor: '#800020',
        mainImage: 'microbiology.jpg'
    },
    {
        name: 'avaliacao-nutricional',
        title: 'AVALIAÇÃO NUTRICIONAL',
        bgColor: '#800020',
        mainImage: 'nutritional-assessment.jpg'
    },
    {
        name: 'tecnica-dietetica',
        title: 'TÉCNICA DIETÉTICA',
        bgColor: '#800020',
        mainImage: 'dietetic-technique.jpg'
    },
    {
        name: 'nutricao-clinica',
        title: 'NUTRIÇÃO CLÍNICA',
        bgColor: '#800020',
        mainImage: 'clinical-nutrition.jpg'
    }
];

// Função para criar imagens de amostra
async function createSampleImages() {
    // Criar diretório de saída se não existir
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    // Criar imagens para cada disciplina
    for (const subject of subjects) {
        await createSubjectImage(subject);
    }

    // Criar imagens de amostra
    await createSampleImage('bioquimica', 'Bioquímica');
    await createSampleImage('tecnica-dietetica', 'Técnica Dietética');
    await createSampleImage('avaliacao-nutricional', 'Avaliação Nutricional');

    // Criar imagens de ícones
    await createIconImages();

    // Criar imagem de laptop showcase
    await createLaptopShowcase();

    // Criar imagens de depoimentos
    await createTestimonialImages();

    // Criar imagem de garantia
    await createGuaranteeImage();

    // Criar imagem da equipe
    await createTeamImage();

    console.log('Todas as imagens foram criadas com sucesso!');
}

// Função para criar imagem de disciplina
async function createSubjectImage(subject) {
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fundo
    ctx.fillStyle = subject.bgColor;
    ctx.fillRect(0, 0, width, height);

    // Título vertical
    ctx.save();
    ctx.translate(100, height / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.font = 'bold 60px Montserrat';
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.fillText(subject.title, 0, 0);
    ctx.restore();

    // Simular páginas de mapas mentais
    drawMapPage(ctx, 200, 100, 200, 400);
    drawMapPage(ctx, 600, 100, 200, 400);

    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(outputDir, `${subject.name}-realistic.png`), buffer);
    console.log(`Imagem criada: ${subject.name}-realistic.png`);
}

// Função para desenhar uma página de mapa mental
function drawMapPage(ctx, x, y, width, height) {
    // Fundo da página
    ctx.fillStyle = 'white';
    ctx.fillRect(x - width / 2, y, width, height);
    
    // Sombra
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    ctx.fillRect(x - width / 2 + 5, y + 5, width, height);
    
    // Conteúdo simulado
    ctx.fillStyle = '#333';
    
    // Título
    ctx.font = 'bold 14px Arial';
    ctx.fillText('Mapa Mental', x - width / 2 + 20, y + 30);
    
    // Linhas de conteúdo
    ctx.font = '12px Arial';
    for (let i = 0; i < 15; i++) {
        const lineY = y + 60 + i * 20;
        const lineWidth = Math.random() * 100 + 50;
        ctx.fillRect(x - width / 2 + 20, lineY, lineWidth, 2);
        
        // Algumas linhas com ramificações
        if (i % 3 === 0) {
            ctx.fillRect(x - width / 2 + 20 + lineWidth, lineY, 2, 20);
            ctx.fillRect(x - width / 2 + 20 + lineWidth, lineY + 20, 40, 2);
        }
    }
    
    // Círculos para simular nós do mapa mental
    for (let i = 0; i < 5; i++) {
        const circleX = x - width / 2 + 50 + Math.random() * 100;
        const circleY = y + 100 + Math.random() * 200;
        const radius = Math.random() * 10 + 5;
        
        ctx.beginPath();
        ctx.arc(circleX, circleY, radius, 0, Math.PI * 2);
        ctx.fillStyle = ['#800020', '#4CAF50', '#FFA500'][Math.floor(Math.random() * 3)];
        ctx.fill();
    }
}

// Função para criar imagem de amostra
async function createSampleImage(name, title) {
    const canvas = createCanvas(600, 800);
    const ctx = canvas.getContext('2d');

    // Fundo
    ctx.fillStyle = 'white';
    ctx.fillRect(0, 0, 600, 800);

    // Título
    ctx.font = 'bold 24px Montserrat';
    ctx.fillStyle = '#800020';
    ctx.textAlign = 'center';
    ctx.fillText(title, 300, 40);

    // Conteúdo do mapa mental
    ctx.font = 'bold 18px Arial';
    ctx.fillStyle = '#333';
    ctx.textAlign = 'left';
    ctx.fillText('Conceitos Principais', 50, 80);

    // Desenhar mapa mental
    drawMapMentalContent(ctx, 300, 400);

    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(outputDir, `sample-${name}.png`), buffer);
    console.log(`Imagem de amostra criada: sample-${name}.png`);
}

// Função para desenhar conteúdo de mapa mental
function drawMapMentalContent(ctx, centerX, centerY) {
    // Nó central
    ctx.beginPath();
    ctx.arc(centerX, centerY, 50, 0, Math.PI * 2);
    ctx.fillStyle = '#800020';
    ctx.fill();
    
    ctx.font = 'bold 14px Arial';
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.fillText('CONCEITO', centerX, centerY);
    ctx.fillText('CENTRAL', centerX, centerY + 20);
    
    // Ramos
    const branches = 6;
    const radius = 150;
    
    for (let i = 0; i < branches; i++) {
        const angle = (i / branches) * Math.PI * 2;
        const x = centerX + Math.cos(angle) * radius;
        const y = centerY + Math.sin(angle) * radius;
        
        // Linha do ramo
        ctx.beginPath();
        ctx.moveTo(centerX, centerY);
        ctx.lineTo(x, y);
        ctx.strokeStyle = '#4CAF50';
        ctx.lineWidth = 3;
        ctx.stroke();
        
        // Nó secundário
        ctx.beginPath();
        ctx.arc(x, y, 30, 0, Math.PI * 2);
        ctx.fillStyle = '#4CAF50';
        ctx.fill();
        
        ctx.font = 'bold 12px Arial';
        ctx.fillStyle = 'white';
        ctx.fillText(`TÓPICO ${i+1}`, x, y);
        
        // Sub-ramos
        const subBranches = 3;
        const subRadius = 70;
        
        for (let j = 0; j < subBranches; j++) {
            const subAngle = angle + ((j - 1) / subBranches) * Math.PI / 2;
            const subX = x + Math.cos(subAngle) * subRadius;
            const subY = y + Math.sin(subAngle) * subRadius;
            
            // Linha do sub-ramo
            ctx.beginPath();
            ctx.moveTo(x, y);
            ctx.lineTo(subX, subY);
            ctx.strokeStyle = '#FFA500';
            ctx.lineWidth = 2;
            ctx.stroke();
            
            // Nó terciário
            ctx.beginPath();
            ctx.arc(subX, subY, 20, 0, Math.PI * 2);
            ctx.fillStyle = '#FFA500';
            ctx.fill();
            
            ctx.font = '10px Arial';
            ctx.fillStyle = 'white';
            ctx.fillText(`SUB ${j+1}`, subX, subY);
        }
    }
}

// Função para criar imagens de ícones
async function createIconImages() {
    const iconNames = ['efficiency', 'flexibility', 'understanding', 'quality', 'pdf', 'validated'];
    const iconColors = ['#800020', '#4CAF50', '#FFA500', '#800020', '#4CAF50', '#FFA500'];
    
    for (let i = 0; i < iconNames.length; i++) {
        const canvas = createCanvas(100, 100);
        const ctx = canvas.getContext('2d');
        
        // Círculo de fundo
        ctx.beginPath();
        ctx.arc(50, 50, 40, 0, Math.PI * 2);
        ctx.fillStyle = iconColors[i];
        ctx.fill();
        
        // Ícone simulado (desenho simples)
        ctx.fillStyle = 'white';
        
        // Desenhos diferentes para cada ícone
        switch (iconNames[i]) {
            case 'efficiency':
                drawClockIcon(ctx, 50, 50, 30);
                break;
            case 'flexibility':
                drawFlexibilityIcon(ctx, 50, 50, 30);
                break;
            case 'understanding':
                drawBrainIcon(ctx, 50, 50, 30);
                break;
            case 'quality':
                drawStarIcon(ctx, 50, 50, 30);
                break;
            case 'pdf':
                drawDocumentIcon(ctx, 50, 50, 30);
                break;
            case 'validated':
                drawCheckmarkIcon(ctx, 50, 50, 30);
                break;
        }
        
        // Salvar imagem
        const buffer = canvas.toBuffer('image/png');
        fs.writeFileSync(path.join(outputDir, `icon-${iconNames[i]}.png`), buffer);
        console.log(`Ícone criado: icon-${iconNames[i]}.png`);
    }
}

// Funções para desenhar ícones
function drawClockIcon(ctx, x, y, size) {
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Ponteiros
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, y - size * 0.7);
    ctx.stroke();
    
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + size * 0.5, y);
    ctx.stroke();
}

function drawFlexibilityIcon(ctx, x, y, size) {
    // Símbolo de flexibilidade (ondas)
    for (let i = 0; i < 3; i++) {
        ctx.beginPath();
        ctx.moveTo(x - size, y - size + i * size/2);
        ctx.bezierCurveTo(
            x - size/2, y - size * 1.5 + i * size/2,
            x + size/2, y - size * 0.5 + i * size/2,
            x + size, y - size + i * size/2
        );
        ctx.strokeStyle = 'white';
        ctx.lineWidth = 3;
        ctx.stroke();
    }
}

function drawBrainIcon(ctx, x, y, size) {
    // Cérebro simplificado
    ctx.beginPath();
    ctx.ellipse(x, y, size * 0.8, size, 0, 0, Math.PI * 2);
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Detalhes do cérebro
    ctx.beginPath();
    ctx.moveTo(x, y - size * 0.5);
    ctx.bezierCurveTo(
        x - size * 0.5, y - size * 0.5,
        x - size * 0.5, y + size * 0.5,
        x, y + size * 0.5
    );
    ctx.stroke();
}

function drawStarIcon(ctx, x, y, size) {
    // Estrela
    const spikes = 5;
    const outerRadius = size;
    const innerRadius = size / 2;
    
    ctx.beginPath();
    for (let i = 0; i < spikes * 2; i++) {
        const radius = i % 2 === 0 ? outerRadius : innerRadius;
        const angle = (i / (spikes * 2)) * Math.PI * 2;
        const pointX = x + Math.cos(angle) * radius;
        const pointY = y + Math.sin(angle) * radius;
        
        if (i === 0) {
            ctx.moveTo(pointX, pointY);
        } else {
            ctx.lineTo(pointX, pointY);
        }
    }
    ctx.closePath();
    ctx.fillStyle = 'white';
    ctx.fill();
}

function drawDocumentIcon(ctx, x, y, size) {
    // Documento
    ctx.fillStyle = 'white';
    ctx.fillRect(x - size * 0.6, y - size * 0.8, size * 1.2, size * 1.6);
    
    // Linhas de texto
    ctx.fillStyle = '#800020';
    for (let i = 0; i < 5; i++) {
        ctx.fillRect(x - size * 0.4, y - size * 0.6 + i * size * 0.3, size * 0.8, size * 0.1);
    }
    
    // Canto dobrado
    ctx.beginPath();
    ctx.moveTo(x + size * 0.6, y - size * 0.8);
    ctx.lineTo(x + size * 0.6, y - size * 0.4);
    ctx.lineTo(x + size * 0.2, y - size * 0.8);
    ctx.closePath();
    ctx.fillStyle = '#4CAF50';
    ctx.fill();
}

function drawCheckmarkIcon(ctx, x, y, size) {
    // Checkmark
    ctx.beginPath();
    ctx.moveTo(x - size * 0.5, y);
    ctx.lineTo(x - size * 0.1, y + size * 0.5);
    ctx.lineTo(x + size * 0.6, y - size * 0.6);
    ctx.strokeStyle = 'white';
    ctx.lineWidth = 5;
    ctx.stroke();
}

// Função para criar imagem de laptop showcase
async function createLaptopShowcase() {
    const canvas = createCanvas(800, 500);
    const ctx = canvas.getContext('2d');
    
    // Fundo
    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(0, 0, 800, 500);
    
    // Laptop
    drawLaptop(ctx, 400, 250, 600, 400);
    
    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(outputDir, 'laptop-showcase.png'), buffer);
    console.log('Imagem de laptop showcase criada: laptop-showcase.png');
}

// Função para desenhar laptop
function drawLaptop(ctx, x, y, width, height) {
    // Tela
    ctx.fillStyle = '#333';
    ctx.fillRect(x - width/2, y - height/2, width, height * 0.7);
    
    // Borda da tela
    ctx.fillStyle = '#222';
    ctx.fillRect(x - width/2 - 10, y - height/2 - 10, width + 20, height * 0.7 + 20);
    
    // Tela interna (conteúdo)
    ctx.fillStyle = 'white';
    ctx.fillRect(x - width/2 + 10, y - height/2 + 10, width - 20, height * 0.7 - 20);
    
    // Conteúdo da tela (mapas mentais)
    drawScreenContent(ctx, x, y - height * 0.15, width - 40, height * 0.6);
    
    // Base do laptop
    ctx.fillStyle = '#222';
    ctx.beginPath();
    ctx.moveTo(x - width/2, y + height * 0.2);
    ctx.lineTo(x + width/2, y + height * 0.2);
    ctx.lineTo(x + width/2 + 30, y + height * 0.35);
    ctx.lineTo(x - width/2 - 30, y + height * 0.35);
    ctx.closePath();
    ctx.fill();
    
    // Touchpad
    ctx.fillStyle = '#444';
    ctx.fillRect(x - 60, y + height * 0.22, 120, 80);
}

// Função para desenhar conteúdo da tela
function drawScreenContent(ctx, x, y, width, height) {
    // Fundo da tela
    ctx.fillStyle = '#800020';
    ctx.fillRect(x - width/2, y - height/2, width, height);
    
    // Título
    ctx.font = 'bold 24px Arial';
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.fillText('MAPAS MENTAIS NUTRIÇÃO', x, y - height/2 + 40);
    
    // Imagens de mapas mentais
    const rows = 2;
    const cols = 3;
    const cardWidth = width / cols * 0.8;
    const cardHeight = height / rows * 0.7;
    
    for (let i = 0; i < rows; i++) {
        for (let j = 0; j < cols; j++) {
            const cardX = x - width/2 + width/cols * (j + 0.5);
            const cardY = y - height/4 + height/2 * i;
            
            // Card de fundo
            ctx.fillStyle = 'white';
            ctx.fillRect(cardX - cardWidth/2, cardY - cardHeight/2, cardWidth, cardHeight);
            
            // Conteúdo do card
            ctx.fillStyle = '#800020';
            ctx.font = 'bold 12px Arial';
            ctx.fillText(`MAPA ${i*cols + j + 1}`, cardX, cardY - cardHeight/4);
            
            // Linhas simulando conteúdo
            ctx.fillStyle = '#333';
            for (let k = 0; k < 5; k++) {
                const lineWidth = Math.random() * 50 + 20;
                ctx.fillRect(cardX - lineWidth/2, cardY + k * 10, lineWidth, 2);
            }
        }
    }
}

// Função para criar imagens de depoimentos
async function createTestimonialImages() {
    for (let i = 1; i <= 3; i++) {
        const canvas = createCanvas(200, 200);
        const ctx = canvas.getContext('2d');
        
        // Fundo circular
        ctx.beginPath();
        ctx.arc(100, 100, 90, 0, Math.PI * 2);
        ctx.fillStyle = '#f5f5f5';
        ctx.fill();
        
        // Silhueta de pessoa
        ctx.beginPath();
        ctx.arc(100, 85, 50, 0, Math.PI * 2);
        ctx.fillStyle = '#800020';
        ctx.fill();
        
        ctx.beginPath();
        ctx.moveTo(70, 140);
        ctx.lineTo(130, 140);
        ctx.lineTo(100, 200);
        ctx.closePath();
        ctx.fillStyle = '#800020';
        ctx.fill();
        
        // Salvar imagem
        const buffer = canvas.toBuffer('image/png');
        fs.writeFileSync(path.join(outputDir, `testimonial-${i}.jpg`), buffer);
        console.log(`Imagem de depoimento criada: testimonial-${i}.jpg`);
    }
}

// Função para criar imagem de garantia
async function createGuaranteeImage() {
    const canvas = createCanvas(300, 300);
    const ctx = canvas.getContext('2d');
    
    // Selo de garantia
    ctx.beginPath();
    ctx.arc(150, 150, 120, 0, Math.PI * 2);
    ctx.fillStyle = '#800020';
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc(150, 150, 100, 0, Math.PI * 2);
    ctx.fillStyle = '#4CAF50';
    ctx.fill();
    
    // Texto
    ctx.font = 'bold 40px Arial';
    ctx.fillStyle = 'white';
    ctx.textAlign = 'center';
    ctx.fillText('7 DIAS', 150, 130);
    
    ctx.font = 'bold 20px Arial';
    ctx.fillText('GARANTIA', 150, 170);
    
    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(outputDir, 'guarantee-seal.png'), buffer);
    console.log('Imagem de garantia criada: guarantee-seal.png');
}

// Função para criar imagem da equipe
async function createTeamImage() {
    const canvas = createCanvas(600, 400);
    const ctx = canvas.getContext('2d');
    
    // Fundo
    ctx.fillStyle = '#f5f5f5';
    ctx.fillRect(0, 0, 600, 400);
    
    // Silhuetas de pessoas
    const people = 4;
    for (let i = 0; i < people; i++) {
        const x = 150 + i * 100;
        const y = 200;
        
        // Cabeça
        ctx.beginPath();
        ctx.arc(x, y - 70, 40, 0, Math.PI * 2);
        ctx.fillStyle = '#800020';
        ctx.fill();
        
        // Corpo
        ctx.beginPath();
        ctx.moveTo(x - 30, y - 30);
        ctx.lineTo(x + 30, y - 30);
        ctx.lineTo(x + 40, y + 100);
        ctx.lineTo(x - 40, y + 100);
        ctx.closePath();
        ctx.fillStyle = '#800020';
        ctx.fill();
    }
    
    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    fs.writeFileSync(path.join(outputDir, 'about-team.jpg'), buffer);
    console.log('Imagem da equipe criada: about-team.jpg');
}

// Executar a criação de imagens
createSampleImages().catch(err => {
    console.error('Erro ao criar imagens:', err);
});
