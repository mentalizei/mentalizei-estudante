// Configuração de integração com a Hotmart
document.addEventListener('DOMContentLoaded', function() {
    // Substituir os links de compra com o link real da Hotmart
    const hotmartProductLink = "https://pay.hotmart.com/XXXXXXXX"; // Substituir pelo link real do produto na Hotmart
    
    // Atualizar todos os links de compra
    const buyButtons = document.querySelectorAll('.btn-buy, .floating-cta a');
    buyButtons.forEach(button => {
        button.href = hotmartProductLink;
    });
    
    // Configurar links de CTA para a Hotmart
    const ctaButtons = document.querySelectorAll('.btn-cta');
    ctaButtons.forEach(button => {
        if (button.textContent.includes('GARANTIR') || button.textContent.includes('QUERO') || 
            button.textContent.includes('REALIZAR') || button.textContent.includes('COMPRAR')) {
            button.href = hotmartProductLink;
        }
    });
    
    // Configurar rastreamento de conversão da Hotmart
    const hotmartTrackingScript = document.createElement('script');
    hotmartTrackingScript.innerHTML = `
        // Código de rastreamento da Hotmart
        (function(h,o,t,m,a,r,t){
            h['HotmartAnalyticsObject']=a;
            h[a]=h[a]||function(){
                (h[a].q=h[a].q||[]).push(arguments)
            };
            t=o.createElement(m);
            r=o.getElementsByTagName(m)[0];
            t.async=1;
            t.src=hotmartTrackingUrl;
            r.parentNode.insertBefore(t,r);
        })(window,document,'script','//analytics.hotmart.com/hotmart-analytics.js','ha');
        
        ha('create', 'XXXXXXXX'); // Substituir pelo código de rastreamento da Hotmart
        ha('send', 'pageview');
    `;
    
    document.head.appendChild(hotmartTrackingScript);
    
    // Adicionar pixel de conversão para o botão de compra
    const buyNowButtons = document.querySelectorAll('.btn-buy, .btn-cta');
    buyNowButtons.forEach(button => {
        button.addEventListener('click', function() {
            // Registrar evento de clique no botão de compra
            if (typeof ha !== 'undefined') {
                ha('send', 'event', {
                    eventCategory: 'Compra',
                    eventAction: 'Clique',
                    eventLabel: 'Botão de Compra'
                });
            }
        });
    });
    
    // Configurar formulário de upsell após compra
    function createUpsellPopup() {
        const upsellPopup = document.createElement('div');
        upsellPopup.className = 'upsell-popup';
        upsellPopup.innerHTML = `
            <div class="upsell-popup-content">
                <span class="close-upsell">&times;</span>
                <h3>Parabéns pela sua compra!</h3>
                <p>Que tal complementar seu material com nosso curso de Técnicas Avançadas de Estudo para Nutrição?</p>
                <div class="upsell-offer">
                    <div class="upsell-price">
                        <span class="old-price">R$297</span>
                        <span class="new-price">R$147</span>
                    </div>
                    <p>Oferta exclusiva para quem comprou o Pack de Mapas Mentais</p>
                </div>
                <a href="https://pay.hotmart.com/YYYYYYYY" class="btn-cta" target="_blank">ADICIONAR AO MEU PEDIDO</a>
                <button class="btn-skip">Não, obrigado</button>
            </div>
        `;
        
        document.body.appendChild(upsellPopup);
        
        // Estilo para o pop-up de upsell
        const style = document.createElement('style');
        style.textContent = `
            .upsell-popup {
                position: fixed;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background-color: rgba(0, 0, 0, 0.7);
                display: flex;
                justify-content: center;
                align-items: center;
                z-index: 9999;
            }
            
            .upsell-popup-content {
                background-color: white;
                padding: 30px;
                border-radius: 10px;
                max-width: 500px;
                text-align: center;
                position: relative;
            }
            
            .close-upsell {
                position: absolute;
                top: 10px;
                right: 15px;
                font-size: 24px;
                cursor: pointer;
            }
            
            .upsell-offer {
                background-color: #f9f9f9;
                padding: 15px;
                margin: 15px 0;
                border-radius: 5px;
            }
            
            .upsell-price {
                margin: 10px 0;
            }
            
            .upsell-price .old-price {
                text-decoration: line-through;
                color: #999;
                margin-right: 10px;
            }
            
            .upsell-price .new-price {
                font-size: 24px;
                font-weight: bold;
                color: #800020;
            }
            
            .btn-skip {
                background: none;
                border: none;
                color: #666;
                margin-top: 15px;
                cursor: pointer;
                text-decoration: underline;
            }
        `;
        
        document.head.appendChild(style);
        
        // Fechar o pop-up ao clicar no X ou no botão "Não, obrigado"
        document.querySelector('.close-upsell').addEventListener('click', function() {
            document.body.removeChild(upsellPopup);
        });
        
        document.querySelector('.btn-skip').addEventListener('click', function() {
            document.body.removeChild(upsellPopup);
        });
    }
    
    // Verificar se o usuário veio da página de confirmação da Hotmart
    if (window.location.search.includes('thank-you=true')) {
        createUpsellPopup();
    }
    
    // Configurar parâmetros UTM para rastreamento de campanhas
    function getUTMParameters() {
        const utmParams = {};
        const queryString = window.location.search.substring(1);
        const pairs = queryString.split('&');
        
        for (let i = 0; i < pairs.length; i++) {
            const pair = pairs[i].split('=');
            if (pair[0].startsWith('utm_')) {
                utmParams[pair[0]] = decodeURIComponent(pair[1] || '');
            }
        }
        
        return utmParams;
    }
    
    // Adicionar parâmetros UTM aos links da Hotmart
    const utmParams = getUTMParameters();
    if (Object.keys(utmParams).length > 0) {
        const hotmartLinks = document.querySelectorAll('a[href*="hotmart.com"]');
        hotmartLinks.forEach(link => {
            let url = new URL(link.href);
            
            for (const [key, value] of Object.entries(utmParams)) {
                url.searchParams.set(key, value);
            }
            
            link.href = url.toString();
        });
    }
});
