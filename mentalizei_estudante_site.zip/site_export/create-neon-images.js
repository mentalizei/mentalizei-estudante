// Script para criar imagens no estilo científico neon para as disciplinas
const fs = require('fs');
const { createCanvas, loadImage } = require('canvas');
const path = require('path');

// Configurações
const outputDir = path.join(__dirname, 'images');
const width = 800;
const height = 500;
const backgroundColor = '#0a1a1f'; // Fundo escuro
const neonGreen = '#00ff7f';
const neonPink = '#ff3399';

// Definição das disciplinas
const subjects = [
    {
        name: 'bioquimica',
        title: 'BIOQUÍMICA',
        mainElement: 'dna',
        elements: [
            { type: 'molecule', x: 150, y: 150, size: 80, color: neonGreen },
            { type: 'hexagon', x: 650, y: 350, size: 60, color: neonPink },
            { type: 'circle', x: 700, y: 150, size: 40, color: neonGreen },
            { type: 'grid', x: 100, y: 350, size: 100, color: neonPink }
        ]
    },
    {
        name: 'fisiologia',
        title: 'FISIOLOGIA HUMANA',
        mainElement: 'heart',
        elements: [
            { type: 'pulse', x: 150, y: 250, width: 200, color: neonPink },
            { type: 'cell', x: 650, y: 150, size: 70, color: neonGreen },
            { type: 'circle', x: 700, y: 350, size: 50, color: neonPink },
            { type: 'grid', x: 100, y: 150, size: 80, color: neonGreen }
        ]
    },
    {
        name: 'anatomia',
        title: 'ANATOMIA HUMANA',
        mainElement: 'body',
        elements: [
            { type: 'bone', x: 150, y: 150, size: 80, color: neonGreen },
            { type: 'circle', x: 650, y: 350, size: 60, color: neonPink },
            { type: 'grid', x: 700, y: 150, size: 90, color: neonGreen },
            { type: 'molecule', x: 100, y: 350, size: 70, color: neonPink }
        ]
    },
    {
        name: 'microbiologia',
        title: 'MICROBIOLOGIA',
        mainElement: 'bacteria',
        elements: [
            { type: 'virus', x: 150, y: 150, size: 70, color: neonPink },
            { type: 'cell', x: 650, y: 350, size: 80, color: neonGreen },
            { type: 'circle', x: 700, y: 150, size: 40, color: neonPink },
            { type: 'grid', x: 100, y: 350, size: 100, color: neonGreen }
        ]
    },
    {
        name: 'avaliacao-nutricional',
        title: 'AVALIAÇÃO NUTRICIONAL',
        mainElement: 'nutrition',
        elements: [
            { type: 'chart', x: 150, y: 150, size: 80, color: neonGreen },
            { type: 'apple', x: 650, y: 350, size: 60, color: neonPink },
            { type: 'circle', x: 700, y: 150, size: 50, color: neonGreen },
            { type: 'grid', x: 100, y: 350, size: 90, color: neonPink }
        ]
    },
    {
        name: 'tecnica-dietetica',
        title: 'TÉCNICA DIETÉTICA',
        mainElement: 'food',
        elements: [
            { type: 'plate', x: 150, y: 150, size: 80, color: neonPink },
            { type: 'molecule', x: 650, y: 350, size: 70, color: neonGreen },
            { type: 'circle', x: 700, y: 150, size: 40, color: neonPink },
            { type: 'grid', x: 100, y: 350, size: 100, color: neonGreen }
        ]
    },
    {
        name: 'nutricao-clinica',
        title: 'NUTRIÇÃO CLÍNICA',
        mainElement: 'medical',
        elements: [
            { type: 'heart', x: 150, y: 150, size: 70, color: neonGreen },
            { type: 'chart', x: 650, y: 350, size: 80, color: neonPink },
            { type: 'circle', x: 700, y: 150, size: 50, color: neonGreen },
            { type: 'grid', x: 100, y: 350, size: 90, color: neonPink }
        ]
    }
];

// Função principal para criar as imagens
async function createImages() {
    // Verificar se o diretório existe
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    // Criar imagens para cada disciplina
    for (const subject of subjects) {
        await createSubjectImage(subject);
    }

    console.log('Todas as imagens foram criadas com sucesso!');
}

// Função para criar uma imagem de disciplina
async function createSubjectImage(subject) {
    const canvas = createCanvas(width, height);
    const ctx = canvas.getContext('2d');

    // Fundo
    ctx.fillStyle = backgroundColor;
    ctx.fillRect(0, 0, width, height);

    // Adicionar efeito de gradiente
    const gradient = ctx.createRadialGradient(width/2, height/2, 50, width/2, height/2, 400);
    gradient.addColorStop(0, 'rgba(0, 255, 127, 0.2)');
    gradient.addColorStop(0.5, 'rgba(255, 51, 153, 0.05)');
    gradient.addColorStop(1, 'rgba(10, 26, 31, 0)');
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, width, height);

    // Desenhar grid de fundo
    drawBackgroundGrid(ctx);

    // Desenhar elementos decorativos
    for (const element of subject.elements) {
        drawElement(ctx, element);
    }

    // Desenhar elemento principal
    drawMainElement(ctx, subject.mainElement);

    // Desenhar título
    drawTitle(ctx, subject.title);

    // Salvar imagem
    const buffer = canvas.toBuffer('image/png');
    const outputPath = path.join(outputDir, `${subject.name}-realistic.png`);
    fs.writeFileSync(outputPath, buffer);
    console.log(`Imagem criada: ${outputPath}`);
}

// Função para desenhar grid de fundo
function drawBackgroundGrid(ctx) {
    ctx.strokeStyle = 'rgba(0, 255, 127, 0.1)';
    ctx.lineWidth = 1;

    // Linhas horizontais
    for (let y = 0; y < height; y += 20) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(width, y);
        ctx.stroke();
    }

    // Linhas verticais
    for (let x = 0; x < width; x += 20) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, height);
        ctx.stroke();
    }

    // Círculos decorativos
    for (let i = 0; i < 5; i++) {
        const x = Math.random() * width;
        const y = Math.random() * height;
        const radius = 5 + Math.random() * 15;
        
        ctx.beginPath();
        ctx.arc(x, y, radius, 0, Math.PI * 2);
        ctx.strokeStyle = Math.random() > 0.5 ? 'rgba(0, 255, 127, 0.2)' : 'rgba(255, 51, 153, 0.2)';
        ctx.stroke();
    }
}

// Função para desenhar o título
function drawTitle(ctx, title) {
    ctx.font = 'bold 40px Montserrat';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    
    // Sombra neon
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 15;
    ctx.fillStyle = neonPink;
    ctx.fillText(title, width/2, height - 50);
    
    // Resetar sombra
    ctx.shadowBlur = 0;
}

// Função para desenhar elementos decorativos
function drawElement(ctx, element) {
    ctx.save();
    
    switch (element.type) {
        case 'molecule':
            drawMolecule(ctx, element);
            break;
        case 'hexagon':
            drawHexagon(ctx, element);
            break;
        case 'circle':
            drawCircle(ctx, element);
            break;
        case 'grid':
            drawGrid(ctx, element);
            break;
        case 'pulse':
            drawPulse(ctx, element);
            break;
        case 'cell':
            drawCell(ctx, element);
            break;
        case 'bone':
            drawBone(ctx, element);
            break;
        case 'virus':
            drawVirus(ctx, element);
            break;
        case 'chart':
            drawChart(ctx, element);
            break;
        case 'apple':
            drawApple(ctx, element);
            break;
        case 'plate':
            drawPlate(ctx, element);
            break;
        case 'heart':
            drawHeart(ctx, element);
            break;
    }
    
    ctx.restore();
}

// Função para desenhar o elemento principal
function drawMainElement(ctx, type) {
    const centerX = width / 2;
    const centerY = height / 2;
    
    ctx.save();
    
    // Círculo de fundo
    const gradient = ctx.createRadialGradient(centerX, centerY, 50, centerX, centerY, 150);
    gradient.addColorStop(0, 'rgba(0, 255, 127, 0.3)');
    gradient.addColorStop(1, 'rgba(0, 255, 127, 0)');
    
    ctx.beginPath();
    ctx.arc(centerX, centerY, 150, 0, Math.PI * 2);
    ctx.fillStyle = gradient;
    ctx.fill();
    
    // Círculo de borda
    ctx.beginPath();
    ctx.arc(centerX, centerY, 150, 0, Math.PI * 2);
    ctx.strokeStyle = neonPink;
    ctx.lineWidth = 2;
    ctx.stroke();
    
    // Desenhar elemento específico
    switch (type) {
        case 'dna':
            drawDNA(ctx, centerX, centerY);
            break;
        case 'heart':
            drawLargeHeart(ctx, centerX, centerY);
            break;
        case 'body':
            drawBody(ctx, centerX, centerY);
            break;
        case 'bacteria':
            drawLargeBacteria(ctx, centerX, centerY);
            break;
        case 'nutrition':
            drawNutrition(ctx, centerX, centerY);
            break;
        case 'food':
            drawFoodPlate(ctx, centerX, centerY);
            break;
        case 'medical':
            drawMedical(ctx, centerX, centerY);
            break;
    }
    
    ctx.restore();
}

// Funções para desenhar elementos específicos
function drawMolecule(ctx, element) {
    const { x, y, size, color } = element;
    
    // Desenhar átomos e ligações
    const atoms = [
        { x: x, y: y },
        { x: x + size/2, y: y - size/2 },
        { x: x - size/2, y: y - size/2 },
        { x: x, y: y - size },
        { x: x + size/2, y: y + size/2 },
        { x: x - size/2, y: y + size/2 }
    ];
    
    // Ligações
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    
    for (let i = 1; i < atoms.length; i++) {
        ctx.beginPath();
        ctx.moveTo(atoms[0].x, atoms[0].y);
        ctx.lineTo(atoms[i].x, atoms[i].y);
        ctx.stroke();
    }
    
    // Átomos
    atoms.forEach(atom => {
        ctx.beginPath();
        ctx.arc(atom.x, atom.y, size/10, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
    });
}

function drawHexagon(ctx, element) {
    const { x, y, size, color } = element;
    
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2;
        const pointX = x + size * Math.cos(angle);
        const pointY = y + size * Math.sin(angle);
        
        if (i === 0) {
            ctx.moveTo(pointX, pointY);
        } else {
            ctx.lineTo(pointX, pointY);
        }
    }
    ctx.closePath();
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
}

function drawCircle(ctx, element) {
    const { x, y, size, color } = element;
    
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Círculo interno
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.stroke();
}

function drawGrid(ctx, element) {
    const { x, y, size, color } = element;
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 1;
    ctx.shadowColor = color;
    ctx.shadowBlur = 5;
    
    // Linhas horizontais
    for (let i = 0; i <= 5; i++) {
        ctx.beginPath();
        ctx.moveTo(x - size/2, y - size/2 + i * size/5);
        ctx.lineTo(x + size/2, y - size/2 + i * size/5);
        ctx.stroke();
    }
    
    // Linhas verticais
    for (let i = 0; i <= 5; i++) {
        ctx.beginPath();
        ctx.moveTo(x - size/2 + i * size/5, y - size/2);
        ctx.lineTo(x - size/2 + i * size/5, y + size/2);
        ctx.stroke();
    }
}

function drawPulse(ctx, element) {
    const { x, y, width, color } = element;
    
    ctx.beginPath();
    ctx.moveTo(x - width/2, y);
    ctx.lineTo(x - width/3, y);
    ctx.lineTo(x - width/4, y - 30);
    ctx.lineTo(x - width/6, y + 30);
    ctx.lineTo(x, y - 15);
    ctx.lineTo(x + width/6, y + 45);
    ctx.lineTo(x + width/4, y);
    ctx.lineTo(x + width/2, y);
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 3;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
}

function drawCell(ctx, element) {
    const { x, y, size, color } = element;
    
    // Membrana celular
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Núcleo
    ctx.beginPath();
    ctx.arc(x, y, size/3, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.stroke();
    
    // Organelas
    for (let i = 0; i < 5; i++) {
        const angle = (i / 5) * Math.PI * 2;
        const orgX = x + (size * 0.6) * Math.cos(angle);
        const orgY = y + (size * 0.6) * Math.sin(angle);
        
        ctx.beginPath();
        ctx.arc(orgX, orgY, size/10, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.5;
        ctx.fill();
        ctx.globalAlpha = 1;
    }
}

function drawBone(ctx, element) {
    const { x, y, size, color } = element;
    
    // Desenhar osso
    ctx.beginPath();
    
    // Extremidade superior
    ctx.arc(x - size/4, y - size/2, size/4, 0, Math.PI * 2);
    ctx.arc(x + size/4, y - size/2, size/4, 0, Math.PI * 2);
    
    // Corpo do osso
    ctx.moveTo(x - size/8, y - size/2);
    ctx.lineTo(x - size/8, y + size/2);
    ctx.moveTo(x + size/8, y - size/2);
    ctx.lineTo(x + size/8, y + size/2);
    
    // Extremidade inferior
    ctx.arc(x - size/4, y + size/2, size/4, 0, Math.PI * 2);
    ctx.arc(x + size/4, y + size/2, size/4, 0, Math.PI * 2);
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
}

function drawVirus(ctx, element) {
    const { x, y, size, color } = element;
    
    // Corpo do vírus
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Espículas
    for (let i = 0; i < 12; i++) {
        const angle = (i / 12) * Math.PI * 2;
        const startX = x + (size/2) * Math.cos(angle);
        const startY = y + (size/2) * Math.sin(angle);
        const endX = x + size * Math.cos(angle);
        const endY = y + size * Math.sin(angle);
        
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        ctx.lineTo(endX, endY);
        ctx.stroke();
        
        // Ponta da espícula
        ctx.beginPath();
        ctx.arc(endX, endY, size/15, 0, Math.PI * 2);
        ctx.fillStyle = color;
        ctx.fill();
    }
}

function drawChart(ctx, element) {
    const { x, y, size, color } = element;
    
    // Eixos
    ctx.beginPath();
    ctx.moveTo(x - size/2, y + size/2);
    ctx.lineTo(x - size/2, y - size/2);
    ctx.lineTo(x + size/2, y - size/2);
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Barras do gráfico
    const barWidth = size/6;
    const heights = [size/3, size/1.5, size/2, size/2.5, size/4];
    
    for (let i = 0; i < 5; i++) {
        const barX = x - size/2 + barWidth/2 + i * barWidth;
        const barHeight = heights[i];
        
        ctx.beginPath();
        ctx.rect(barX, y + size/2 - barHeight, barWidth * 0.8, barHeight);
        ctx.fillStyle = color;
        ctx.globalAlpha = 0.3;
        ctx.fill();
        ctx.globalAlpha = 1;
        ctx.stroke();
    }
}

function drawApple(ctx, element) {
    const { x, y, size, color } = element;
    
    // Corpo da maçã
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Haste
    ctx.beginPath();
    ctx.moveTo(x, y - size/2);
    ctx.quadraticCurveTo(x, y - size/1.5, x + size/10, y - size/1.5);
    ctx.stroke();
    
    // Folha
    ctx.beginPath();
    ctx.moveTo(x, y - size/1.8);
    ctx.quadraticCurveTo(x + size/4, y - size/1.5, x + size/8, y - size/2.5);
    ctx.quadraticCurveTo(x + size/10, y - size/2, x, y - size/1.8);
    ctx.fillStyle = neonGreen;
    ctx.fill();
    ctx.strokeStyle = neonGreen;
    ctx.stroke();
}

function drawPlate(ctx, element) {
    const { x, y, size, color } = element;
    
    // Prato
    ctx.beginPath();
    ctx.arc(x, y, size/2, 0, Math.PI * 2);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Borda interna
    ctx.beginPath();
    ctx.arc(x, y, size/3, 0, Math.PI * 2);
    ctx.stroke();
    
    // Utensílios
    ctx.beginPath();
    ctx.moveTo(x - size/4, y - size/4);
    ctx.lineTo(x - size/4, y + size/4);
    ctx.moveTo(x + size/4, y - size/4);
    ctx.lineTo(x + size/4, y + size/4);
    ctx.stroke();
}

function drawHeart(ctx, element) {
    const { x, y, size, color } = element;
    
    ctx.beginPath();
    ctx.moveTo(x, y + size/4);
    
    // Lado esquerdo
    ctx.bezierCurveTo(
        x - size/2, y, 
        x - size/2, y - size/2, 
        x, y - size/4
    );
    
    // Lado direito
    ctx.bezierCurveTo(
        x + size/2, y - size/2, 
        x + size/2, y, 
        x, y + size/4
    );
    
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    ctx.fillStyle = color;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
}

// Funções para desenhar elementos principais
function drawDNA(ctx, x, y) {
    const height = 200;
    const width = 60;
    const steps = 10;
    const stepHeight = height / steps;
    
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    
    // Hélice 1
    ctx.beginPath();
    for (let i = 0; i <= steps; i++) {
        const curY = y - height/2 + i * stepHeight;
        const xOffset = width/2 * Math.sin(i * Math.PI / (steps/2));
        
        if (i === 0) {
            ctx.moveTo(x + xOffset, curY);
        } else {
            ctx.lineTo(x + xOffset, curY);
        }
    }
    ctx.stroke();
    
    // Hélice 2
    ctx.beginPath();
    for (let i = 0; i <= steps; i++) {
        const curY = y - height/2 + i * stepHeight;
        const xOffset = width/2 * Math.sin((i * Math.PI / (steps/2)) + Math.PI);
        
        if (i === 0) {
            ctx.moveTo(x + xOffset, curY);
        } else {
            ctx.lineTo(x + xOffset, curY);
        }
    }
    ctx.stroke();
    
    // Conexões
    ctx.strokeStyle = neonPink;
    ctx.shadowColor = neonPink;
    
    for (let i = 0; i < steps; i += 2) {
        const curY = y - height/2 + i * stepHeight;
        const xOffset1 = width/2 * Math.sin(i * Math.PI / (steps/2));
        const xOffset2 = width/2 * Math.sin((i * Math.PI / (steps/2)) + Math.PI);
        
        ctx.beginPath();
        ctx.moveTo(x + xOffset1, curY);
        ctx.lineTo(x + xOffset2, curY);
        ctx.stroke();
    }
    
    // Adicionar folhas no topo (como na imagem de referência)
    drawLeaves(ctx, x, y - height/2 - 30);
}

function drawLeaves(ctx, x, y) {
    // Folha esquerda
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.bezierCurveTo(
        x - 20, y - 15,
        x - 40, y - 10,
        x - 30, y + 20
    );
    ctx.bezierCurveTo(
        x - 20, y + 10,
        x - 10, y + 5,
        x, y
    );
    
    ctx.fillStyle = neonGreen;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    ctx.fill();
    
    // Folha direita
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.bezierCurveTo(
        x + 20, y - 20,
        x + 40, y - 15,
        x + 30, y + 15
    );
    ctx.bezierCurveTo(
        x + 20, y + 5,
        x + 10, y,
        x, y
    );
    
    ctx.fill();
    
    // Caule
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x, y + 30);
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 2;
    ctx.stroke();
}

function drawLargeHeart(ctx, x, y) {
    const size = 100;
    
    ctx.beginPath();
    ctx.moveTo(x, y + size/2);
    
    // Lado esquerdo
    ctx.bezierCurveTo(
        x - size, y, 
        x - size, y - size, 
        x, y - size/2
    );
    
    // Lado direito
    ctx.bezierCurveTo(
        x + size, y - size, 
        x + size, y, 
        x, y + size/2
    );
    
    ctx.strokeStyle = neonPink;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 15;
    ctx.stroke();
    
    ctx.fillStyle = neonPink;
    ctx.globalAlpha = 0.2;
    ctx.fill();
    ctx.globalAlpha = 1;
    
    // Pulso dentro do coração
    ctx.beginPath();
    ctx.moveTo(x - 70, y);
    ctx.lineTo(x - 40, y);
    ctx.lineTo(x - 30, y - 20);
    ctx.lineTo(x - 10, y + 30);
    ctx.lineTo(x + 10, y - 10);
    ctx.lineTo(x + 30, y + 20);
    ctx.lineTo(x + 40, y);
    ctx.lineTo(x + 70, y);
    
    ctx.strokeStyle = neonGreen;
    ctx.shadowColor = neonGreen;
    ctx.stroke();
}

function drawBody(ctx, x, y) {
    const height = 200;
    
    // Silhueta do corpo
    ctx.beginPath();
    
    // Cabeça
    ctx.arc(x, y - height/2 + 25, 25, 0, Math.PI * 2);
    
    // Corpo
    ctx.moveTo(x, y - height/2 + 50);
    ctx.lineTo(x, y + height/2 - 50);
    
    // Braços
    ctx.moveTo(x, y - height/4);
    ctx.lineTo(x - 50, y);
    ctx.moveTo(x, y - height/4);
    ctx.lineTo(x + 50, y);
    
    // Pernas
    ctx.moveTo(x, y + height/2 - 50);
    ctx.lineTo(x - 30, y + height/2);
    ctx.moveTo(x, y + height/2 - 50);
    ctx.lineTo(x + 30, y + height/2);
    
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    ctx.stroke();
    
    // Adicionar elementos anatômicos
    // Coração
    const heartX = x - 15;
    const heartY = y - height/6;
    const heartSize = 20;
    
    ctx.beginPath();
    ctx.moveTo(heartX, heartY + heartSize/4);
    
    // Lado esquerdo
    ctx.bezierCurveTo(
        heartX - heartSize/2, heartY, 
        heartX - heartSize/2, heartY - heartSize/2, 
        heartX, heartY - heartSize/4
    );
    
    // Lado direito
    ctx.bezierCurveTo(
        heartX + heartSize/2, heartY - heartSize/2, 
        heartX + heartSize/2, heartY, 
        heartX, heartY + heartSize/4
    );
    
    ctx.strokeStyle = neonPink;
    ctx.shadowColor = neonPink;
    ctx.stroke();
    
    ctx.fillStyle = neonPink;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    
    // Pulmões
    ctx.beginPath();
    ctx.arc(x - 20, y - height/5, 15, 0, Math.PI * 2);
    ctx.arc(x + 20, y - height/5, 15, 0, Math.PI * 2);
    ctx.strokeStyle = neonPink;
    ctx.shadowColor = neonPink;
    ctx.stroke();
}

function drawLargeBacteria(ctx, x, y) {
    const size = 100;
    
    // Corpo da bactéria
    ctx.beginPath();
    ctx.ellipse(x, y, size, size/2, 0, 0, Math.PI * 2);
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    ctx.stroke();
    
    ctx.fillStyle = neonGreen;
    ctx.globalAlpha = 0.2;
    ctx.fill();
    ctx.globalAlpha = 1;
    
    // Detalhes internos
    for (let i = 0; i < 5; i++) {
        const innerX = x - size/2 + i * size/4;
        const innerY = y;
        
        ctx.beginPath();
        ctx.arc(innerX, innerY, size/10, 0, Math.PI * 2);
        ctx.fillStyle = neonPink;
        ctx.globalAlpha = 0.5;
        ctx.fill();
        ctx.globalAlpha = 1;
    }
    
    // Flagelos
    for (let i = 0; i < 8; i++) {
        const angle = (i / 8) * Math.PI * 2;
        const startX = x + size * Math.cos(angle);
        const startY = y + (size/2) * Math.sin(angle);
        
        ctx.beginPath();
        ctx.moveTo(startX, startY);
        
        const cp1x = startX + 20 * Math.cos(angle);
        const cp1y = startY + 20 * Math.sin(angle);
        const cp2x = startX + 40 * Math.cos(angle + 0.5);
        const cp2y = startY + 40 * Math.sin(angle + 0.5);
        const endX = startX + 60 * Math.cos(angle);
        const endY = startY + 60 * Math.sin(angle);
        
        ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, endX, endY);
        
        ctx.strokeStyle = neonPink;
        ctx.shadowColor = neonPink;
        ctx.stroke();
    }
}

function drawNutrition(ctx, x, y) {
    const size = 100;
    
    // Tubo de ensaio
    ctx.beginPath();
    ctx.moveTo(x - size/4, y - size);
    ctx.lineTo(x - size/4, y + size/2);
    ctx.arc(x, y + size/2, size/4, Math.PI, 0, false);
    ctx.lineTo(x + size/4, y - size);
    
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    ctx.stroke();
    
    // Conteúdo do tubo
    ctx.beginPath();
    ctx.moveTo(x - size/4, y);
    ctx.lineTo(x - size/4, y + size/2);
    ctx.arc(x, y + size/2, size/4, Math.PI, 0, false);
    ctx.lineTo(x + size/4, y);
    ctx.closePath();
    
    ctx.fillStyle = neonGreen;
    ctx.globalAlpha = 0.2;
    ctx.fill();
    ctx.globalAlpha = 1;
    
    // Símbolos nutricionais
    // Proteína
    ctx.beginPath();
    const proteinX = x - 70;
    const proteinY = y - 50;
    const proteinSize = 40;
    
    // Desenhar átomos e ligações
    const atoms = [
        { x: proteinX, y: proteinY },
        { x: proteinX + proteinSize/2, y: proteinY - proteinSize/2 },
        { x: proteinX - proteinSize/2, y: proteinY - proteinSize/2 },
        { x: proteinX, y: proteinY - proteinSize },
        { x: proteinX + proteinSize/2, y: proteinY + proteinSize/2 },
        { x: proteinX - proteinSize/2, y: proteinY + proteinSize/2 }
    ];
    
    // Ligações
    ctx.strokeStyle = neonPink;
    ctx.lineWidth = 2;
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 10;
    
    for (let i = 1; i < atoms.length; i++) {
        ctx.beginPath();
        ctx.moveTo(atoms[0].x, atoms[0].y);
        ctx.lineTo(atoms[i].x, atoms[i].y);
        ctx.stroke();
    }
    
    // Átomos
    atoms.forEach(atom => {
        ctx.beginPath();
        ctx.arc(atom.x, atom.y, proteinSize/10, 0, Math.PI * 2);
        ctx.fillStyle = neonPink;
        ctx.fill();
    });
    
    // Carboidrato
    const hexX = x + 70;
    const hexY = y - 50;
    const hexSize = 30;
    
    ctx.beginPath();
    for (let i = 0; i < 6; i++) {
        const angle = (i / 6) * Math.PI * 2;
        const pointX = hexX + hexSize * Math.cos(angle);
        const pointY = hexY + hexSize * Math.sin(angle);
        
        if (i === 0) {
            ctx.moveTo(pointX, pointY);
        } else {
            ctx.lineTo(pointX, pointY);
        }
    }
    ctx.closePath();
    
    ctx.strokeStyle = neonPink;
    ctx.lineWidth = 2;
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Vitamina
    const circleX = x - 70;
    const circleY = y + 50;
    const circleSize = 25;
    
    ctx.beginPath();
    ctx.arc(circleX, circleY, circleSize, 0, Math.PI * 2);
    ctx.strokeStyle = neonPink;
    ctx.lineWidth = 2;
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 10;
    ctx.stroke();
    
    // Círculo interno
    ctx.beginPath();
    ctx.arc(circleX, circleY, circleSize/2, 0, Math.PI * 2);
    ctx.stroke();
    
    // Mineral
    const gridX = x + 70;
    const gridY = y + 50;
    const gridSize = 40;
    
    ctx.strokeStyle = neonPink;
    ctx.lineWidth = 1;
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 5;
    
    // Linhas horizontais
    for (let i = 0; i <= 5; i++) {
        ctx.beginPath();
        ctx.moveTo(gridX - gridSize/2, gridY - gridSize/2 + i * gridSize/5);
        ctx.lineTo(gridX + gridSize/2, gridY - gridSize/2 + i * gridSize/5);
        ctx.stroke();
    }
    
    // Linhas verticais
    for (let i = 0; i <= 5; i++) {
        ctx.beginPath();
        ctx.moveTo(gridX - gridSize/2 + i * gridSize/5, gridY - gridSize/2);
        ctx.lineTo(gridX - gridSize/2 + i * gridSize/5, gridY + gridSize/2);
        ctx.stroke();
    }
}

function drawFoodPlate(ctx, x, y) {
    const size = 100;
    
    // Prato
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    ctx.stroke();
    
    // Divisões do prato
    ctx.beginPath();
    ctx.moveTo(x, y - size);
    ctx.lineTo(x, y + size);
    ctx.moveTo(x - size, y);
    ctx.lineTo(x + size, y);
    ctx.stroke();
    
    // Alimentos
    // Proteína
    ctx.beginPath();
    ctx.ellipse(x - size/2, y - size/2, size/3, size/4, 0, 0, Math.PI * 2);
    ctx.fillStyle = neonPink;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = neonPink;
    ctx.shadowColor = neonPink;
    ctx.stroke();
    
    // Vegetais
    ctx.beginPath();
    ctx.arc(x + size/2, y - size/2, size/4, 0, Math.PI * 2);
    ctx.fillStyle = neonGreen;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = neonGreen;
    ctx.shadowColor = neonGreen;
    ctx.stroke();
    
    // Carboidratos
    ctx.beginPath();
    ctx.arc(x - size/2, y + size/2, size/4, 0, Math.PI * 2);
    ctx.fillStyle = neonPink;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = neonPink;
    ctx.shadowColor = neonPink;
    ctx.stroke();
    
    // Frutas
    ctx.beginPath();
    ctx.arc(x + size/2, y + size/2, size/4, 0, Math.PI * 2);
    ctx.fillStyle = neonGreen;
    ctx.globalAlpha = 0.3;
    ctx.fill();
    ctx.globalAlpha = 1;
    ctx.strokeStyle = neonGreen;
    ctx.shadowColor = neonGreen;
    ctx.stroke();
}

function drawMedical(ctx, x, y) {
    const size = 100;
    
    // Símbolo médico (cruz)
    ctx.beginPath();
    ctx.rect(x - size/5, y - size/1.5, size/2.5, size*1.2);
    ctx.rect(x - size/1.5, y - size/5, size*1.2, size/2.5);
    
    ctx.fillStyle = neonPink;
    ctx.shadowColor = neonPink;
    ctx.shadowBlur = 15;
    ctx.fill();
    
    // Círculo em volta
    ctx.beginPath();
    ctx.arc(x, y, size, 0, Math.PI * 2);
    ctx.strokeStyle = neonGreen;
    ctx.lineWidth = 3;
    ctx.shadowColor = neonGreen;
    ctx.shadowBlur = 15;
    ctx.stroke();
    
    // Elementos nutricionais ao redor
    // Maçã
    drawApple({x: x - 70, y: y - 70, size: 30, color: neonGreen}, ctx);
    
    // Molécula
    drawMolecule({x: x + 70, y: y - 70, size: 30, color: neonGreen}, ctx);
    
    // Gráfico
    drawChart({x: x - 70, y: y + 70, size: 30, color: neonGreen}, ctx);
    
    // Coração
    drawHeart({x: x + 70, y: y + 70, size: 30, color: neonGreen}, ctx);
}

// Executar a criação de imagens
createImages().catch(err => {
    console.error('Erro ao criar imagens:', err);
});
